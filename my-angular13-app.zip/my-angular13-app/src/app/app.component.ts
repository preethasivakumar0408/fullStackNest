import { Component } from '@angular/core';
import { User } from './user';
import { UserService } from './user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-angular13-app';
   user: User = {
    name: '',
    email: ''
  };

  constructor(private userService: UserService) {}

  submitForm() {
    this.userService.saveUser(this.user).subscribe({
      next: () => {
        alert('User saved successfully');
        this.user = { name: '', email: '' };
      },
      error: (err) => {
        console.error(err);
        alert('Failed to save user');
      }
    });
  }

}
